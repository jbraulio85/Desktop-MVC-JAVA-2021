create definer = root@localhost view vw_info_basic_usuario as
select `usuario_app`.`username`  AS `username`,
       `usuario_app`.`apellidos` AS `apellidos`,
       `usuario_app`.`nombres`   AS `nombres`,
       `usuario_app`.`email`     AS `email`
from `usuario_app`;

