create
    definer = root@localhost procedure sp_AgregarEmpresa(IN EmpresaNombre varchar(75), IN EmpresaTelefono int,
                                                         IN EmpresaDireccion longtext, IN EmpresaPuesto varchar(45))
begin
start transaction;
insert into empresa(empresa.EmpresaNombre,empresa.EmpresaTelefono,empresa.EmpresaDireccion,empresa.EmpresaPuesto)
values (EmpresaNombre,EmpresaTelefono,EmpresaDireccion,EmpresaPuesto);
commit;
end;

