create
    definer = root@localhost procedure sp_EliminarPersona(IN idPersona int)
begin
    delete from persona where persona.idPersona = idPersona;
end;

